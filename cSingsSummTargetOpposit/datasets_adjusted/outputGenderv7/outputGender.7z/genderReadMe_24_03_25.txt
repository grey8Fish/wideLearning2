24_03_25
В файле  gender_classification_v7_0_part0_20240325124654 строка 871 совпадает с строкой 121
из файла gender_classification_v7_1_part0_20240325124654

24_03_27
DataLoader не читает один файл.
В файлах gender_classification_v7_0_part1_20240325124654.csv и 
gender_classification_v7_1_part0_20240325124654.csv жалуется на long_hair.
Для файла outputGender\\gender_classification_v7_1_part2_20240325124654.csv 
в последнем столбце arg_classes не обозначена принадлежность к классу 1.